<?php
error_reporting(0);

/**
 * using mysqli_connect for database connection
 */

$dbServerName = 'localhost';
$dbName = 's_task';
$dbUserName = 'root';
$dbPassword = '';

$mysqli = new mysqli($dbServerName, $dbUserName , $dbPassword, $dbName  );

if ($mysqli->connect_error){
    die('mysql connection failed'.$mysqli->error);
}

?>