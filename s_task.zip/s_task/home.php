<?php
// Turn off all error reporting
error_reporting(0);
require_once("config.php");

if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest')
{
    if (isset($_POST['email'])) {
        $fname = mysqli_real_escape_string($mysqli, $_POST['fname']);
        $lname = mysqli_real_escape_string($mysqli, $_POST['lname']);
        $email = mysqli_real_escape_string($mysqli, $_POST['email']);
        $mobile_no = mysqli_real_escape_string($mysqli, $_POST['mobile_no']);
        $gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
        $country = mysqli_real_escape_string($mysqli, $_POST['country']);
        $state = mysqli_real_escape_string($mysqli, $_POST['state']);
        $city = mysqli_real_escape_string($mysqli, $_POST['city']);
        //$img = mysqli_real_escape_string($mysqli, $_POST['img']);
        $name = $fname." ".$lname;
        $file_name = '';
        if(isset($_FILES['img'])){
            $file_name = $_FILES['img']['name'];
            $file_size = $_FILES['img']['size'];
            $file_tmp = $_FILES['img']['tmp_name'];
            $file_type = $_FILES['img']['type'];
             if($file_size > 2097152) {
                $errors[]='File size must be excately 2 MB';
             }
             
             if(empty($errors)==true) {
                 move_uploaded_file($file_tmp,"./assets/images/".$file_name);
                //echo "Success";
            }
        }
        if (empty($name) || empty($mobile_no) || empty($email)|| empty($gender)|| empty($country)|| empty($state)|| empty($city)) {
            if (empty($name)) {
                echo "Name field is empty";
            }
            
            if (empty($mobile_no)) {
                echo "Mobile_no field is empty.";
            }
            
            if (empty($email)) {
                echo "Email field is empty.";
            }
            if (empty($country)) {
                echo "Country field is empty.";
            }
           exit;
        }else { 
            // If all the fields are filled (not empty) 
            // Insert data into database
            $created_at = date('Y-m-d-H:i:s');
            $result = mysqli_query($mysqli, "INSERT INTO users (`name`, `email`,`mobile_no`, `gender`, `country`, `state`, `city`, `img`, `created_at`) VALUES ('$name', '$email', '$mobile_no', '$gender', '$country', '$state', '$city', '$file_name','$created_at')");
            // Display success message?>

<script>Swal.fire('Data added successfully!').then(function() {window.location = "http://localhost/s_task/index.php";});</script>
<!-- <script>swal({title: "Wow!",text: "Data added successfully!",type: "success"}).then(function() {window.location = "redirectURL";});</script> -->
            <?php
        }
     }
     if($_GET['name'] == 'country'){
         echo getcontry();
         exit;
     }
     if($_GET['name']=='state'){
         echo getstate();
         exit;
     }
     if($_GET['name']=='city'){
     
         echo getcity();
         exit;
     }
     if($_GET['name']==''){
     
        //  echo 'Somthing went wrong';
        //   exit;
     }
}else{
   
    echo "<center><h2>404 Not Found</h2><center>";
    exit;
}
function getcontry()
{
    global $mysqli;
    $selectCountry="select id,name from countries";
    $getCountry = $mysqli->query($selectCountry);
    $getCountry = $getCountry->fetch_all();
    
    $html = '<option value="">Select Country</option>';
        foreach ($getCountry as $key => $a) {
            $html .= '<option value="' . $a[0] . '">' . $a[1] . '</option>';
        }
   return $html;
}
function getstate()
{
    global $mysqli;

    $selectState="select id,name from states where country_id = '".$_REQUEST['id']."'";
    $get_State = $mysqli->query($selectState);
    $get_State = $get_State->fetch_all();
    //print_r($get_State);exit;
    $html = '<option value="">Select State</option>';
        foreach ($get_State as $key => $a) {
            
            // if ($id == $a['state']) {
              $html .= '<option value="' .  $a[0] . '">' . $a[1] . '</option>';
            //}

        }
   return $html;
}
function getcity()
{
    global $mysqli;
    // $selectCity="select * from cities";
    $selectCity="select id,name from cities where state_id = '".$_REQUEST['id']."'";

    $get_City = $mysqli->query($selectCity);
    $get_City = $get_City->fetch_all();
    //$citydata=array('1' => 'Nashik','2' => 'Pune'); 
    $html = '<option value="">Select City</option>';
        foreach ($get_City as $key => $a) {

            // if ($id == $a['state']) {
              $html .= '<option value="' . $a[0] . '">' . $a[1] . '</option>';
            //}

        }
   return $html;
}
